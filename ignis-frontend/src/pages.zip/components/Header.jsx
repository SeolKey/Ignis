import React from 'react';
import { Layout, Menu } from 'antd';
import { Link } from 'react-router-dom';
import '../styles/Header.css';

const { Header: AntHeader } = Layout;

const AppHeader = () => {
  return (
    <AntHeader className="app-header">
      <div className="logo">
        <Link to="/">IGNIS</Link>
      </div>
      <Menu mode="horizontal" defaultSelectedKeys={['home']} className="nav-menu">
        <Menu.Item key="home">
          <Link to="/">홈</Link>
        </Menu.Item>
        <Menu.Item key="donation">
          <Link to="/donation/donation-list-view">기부</Link>
        </Menu.Item>
        <Menu.Item key="volunteer">
          <Link to="/volunteer/volunteer-list-view">봉사</Link>
        </Menu.Item>
        <Menu.Item key="funding">
          <Link to="/funding/funding-list-view">펀딩</Link>
        </Menu.Item>
        <Menu.Item key="mypage">
          <Link to="/user/mypage">마이페이지</Link>
        </Menu.Item>
      </Menu>
    </AntHeader>
  );
};

export default AppHeader;
