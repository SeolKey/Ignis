import React from 'react';
import '../styles/Home.css';
import 'antd/dist/reset.css';

const Home = () => {
  const donationList = [
    { id: 1, title: '기부 제목 1', imagePath: 'image1.jpg' },
    { id: 2, title: '기부 제목 2', imagePath: 'image2.jpg' },
  ];

  const volunteerList = [
    { id: 1, title: '봉사 제목 1', location: '서울', imagePath: 'volunteer1.jpg' },
    { id: 2, title: '봉사 제목 2', location: '부산', imagePath: 'volunteer2.jpg' },
  ];

  const fundingList = [
    { id: 1, title: '펀딩 제목 1', maxPrice: 500000, imagePath: 'funding1.jpg' },
    { id: 2, title: '펀딩 제목 2', maxPrice: 300000, imagePath: 'funding2.jpg' },
  ];

  return (
    <>
      {/* 배너 */}
      <section>
        <div className="banner">
          <h2>여름, 시원한 바람을 느끼려면?</h2>
          <p>새로 입고된 딥 부채 확인해보세요!</p>
          <button onClick={() => window.location.href = '#'}>자세히 보기</button>
        </div>
      </section>

      {/* 기부 */}
      <section className="section">
        <div className="top-bar">
          <h2>기부</h2>
          <a href="/donation/donation-list-view">더 보러가기 →</a>
        </div>
        <div className="card-container">
          {donationList.map(item => (
            <div className="card" key={item.id}>
              <a href={`/donation/donation-detail-view/${item.id}`}>
                <img src={item.imagePath} alt="기부 이미지" />
                <p>{item.title}</p>
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* 봉사 */}
      <section className="section">
        <div className="top-bar">
          <h2>봉사</h2>
          <a href="/volunteer/volunteer-list-view">더 보러가기 →</a>
        </div>
        <div className="card-container">
          {volunteerList.map(item => (
            <div className="card" key={item.id}>
              <a href={`/volunteer/volunteer-detail-view/${item.id}`}>
                <img src={item.imagePath} alt="봉사 이미지" />
                <p>{item.title}</p>
                <p>{item.location}</p>
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* 펀딩 */}
      <section className="section">
        <div className="top-bar">
          <h2>펀딩</h2>
          <a href="/funding/funding-list-view">더 보러가기 →</a>
        </div>
        <div className="card-container">
          {fundingList.map(item => (
            <div className="card" key={item.id}>
              <img src={item.imagePath} alt="펀딩 이미지" />
              <a href={`/funding/funding-detail-view/${item.id}`}>{item.title}</a>
              <p>목표 금액: {item.maxPrice}원</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Home;
